﻿namespace WildFarm.Models

{

    public abstract class Felime : Mammal

    {

        public Felime(string name, string type, double weight, string livigRegion)

            : base(name, type, weight, livigRegion)

        {

        }

    }

}