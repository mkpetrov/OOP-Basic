﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Random_List
{
    public class Random
    {
        static void Main(string[] args)
        {
        }
    }
}
